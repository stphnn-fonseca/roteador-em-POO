class Router():
    def __init__(self, IP_router, marca, modelo, senha_ADM='Ab@123', senha_router='1234', router_ligando=False):

        self.IP_router            = IP_router
        self.senha_router         = senha_router
        self.marca                = marca
        self.modelo               = modelo
        self.senha_ADM            = senha_ADM
        self.router_ligando       = router_ligando
        self.tabela_maquina       = []
        self.desconectadas        = []


#ligando ou desligando o roteador
    def ligando_router(self):
        if self.ligando_router == True:
            print('Roteador esta ligado.')
            return
        
        self.router_ligando = True
        print('Roteador esta ligando.')
        
    def deligando_router(self):
        if self.router_ligando == False:
            print('ATENÇÃO!!! O Roteador esta desligado.')

        self.router_ligando = False
        print('Desligando roteador.')


#adcionando ou retirando aparelhos ao roteador
    def conectar_maquina (self, conectar_maquina , senha_router):
        if senha_router == self.senha_router:
            self.tabela_maquina.append(conectar_maquina )
            print(f'{conectar_maquina } conectado ao roteador {self.marca} {self.modelo}.')
        else:
            print('Esta senha é inválida.') 

    def desconectando_maquina(self, conectar_maquina):
        if conectar_maquina in self.tabela_maquina:
            self.desconectadas.append(conectar_maquina)
            self.tabela_maquina.remove(conectar_maquina)
            print(f'{conectar_maquina} desconectado do roteador {self.marca} {self.modelo}.')


#para mudar a senha do roteador é necessário ter acesso a senha de administrador
    def mudar_senha_router(self, senha_ADM):
        self.senha_ADM = senha_ADM
        print(f'A senha do roteador {self.marca},{self.modelo} foi alterada.')


#menu de informações
    def menu_de_informacao(self):
        print('Menu de informações \n\n')
        print(f'Marca: {self.marca}\n')
        print(f'Modelo: {self.modelo}\n')
        print(f'IP do roteador: {self.IP_router}\n') 
        print(f'Aparelhos conectados: {self.tabela_maquina }\n')  
        print(f'Aparelhos desconectados: {self.desconectadas}\n')



roteador_1 = Router('Cisco', '192.168.1.0', 'D-Link')

roteador_1.conectar_maquina('pc','1234')
roteador_1.conectar_maquina('pc2','1234')
roteador_1.conectar_maquina('leptop','1234')
roteador_1.conectar_maquina('dispositivo móvel','1234')
roteador_1.menu_de_informacao()


roteador_1.desconectando_maquina('pc2')
roteador_1.menu_de_informacao()


roteador_1.mudar_senha_router('Senha$123')
roteador_1.menu_de_informacao()





